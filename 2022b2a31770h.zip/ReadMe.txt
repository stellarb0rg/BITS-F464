Akshaya Reddy Modugu - 2022A8PS0562H
SriRoop Gadagoju - 2022AAPS0439H
Swarnadeep Karmakar - 2022B2A31770H